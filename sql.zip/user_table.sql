CREATE TABLE users(
	uno 	INTEGER NOT NULL COMMENT '회원일련번호',
    id		VARCHAR(100) NOT NULL COMMENT '아이디',
	pwd		VARCHAR(100) NOT NULL COMMENT '암호',
    uname	VARCHAR(50) NOT NULL COMMENT '이름',
    gender	VARCHAR(50) NOT NULL COMMENT '성별',
    email 	VARCHAR(40) NOT NULL COMMENT '이메일',
	upoint 	INTEGER NOT NULL COMMENT '포인트',
    adate DATE COMMENT '출석날짜'
)
COMMENT '회원기본정보';

ALTER TABLE users
	ADD CONSTRAINT users_pk_uno 
		PRIMARY KEY(uno);
        
CREATE UNIQUE INDEX users_uix_id
	ON users(id asc);
    
CREATE UNIQUE INDEX users_uix_email
	ON users(email asc);

-- 시퀀스 대신 사용, 자동으로 1씩 증가
ALTER TABLE users
	MODIFY COLUMN uno INTEGER NOT NULL AUTO_INCREMENT
    COMMENT '회원일련번호';
    
INSERT INTO users(id,pwd,uname,gender,email,upoint)
VALUES ('u1','1111','이형균','남자','u1@test.com',500);
INSERT INTO users(id,pwd,uname,gender,email,upoint)
VALUES ('u2','1111','이기철','남자','u2@test.com',500);
INSERT INTO users(id,pwd,uname,gender,email,upoint)
VALUES ('u3','1111','김경민','남자','u3@test.com',500);
INSERT INTO users(id,pwd,uname,gender,email,upoint)
VALUES ('u4','1111','박원희','남자','u4@test.com',500);
INSERT INTO users(id,pwd,uname,gender,email,upoint)
VALUES ('u5','1111','문창훈','남자','u5@test.com',500);

COMMIT;

SELECT * FROM studydb.users;












