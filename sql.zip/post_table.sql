create table post(
pno INTEGER NOT NULL COMMENT '게시글번호',
uid varchar(255) not null comment '회원아이디',
title varchar(255) not null comment '게시글제목',
content text not null comment '내용',
cre_date datetime not null comment '작성일'
)
comment '게시판';

alter table post add constraint PK_BOARD primary key(pno);

alter table post modify column pno integer not null auto_increment comment '게시글번호';